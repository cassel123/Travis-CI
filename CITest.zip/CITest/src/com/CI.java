package com;

public class CI {
	public static void main(String[] arg)
	{
		System.out.println("Travis CI");
	}

}


